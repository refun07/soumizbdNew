<?php

namespace App\View\Components\backend\forms;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

class FooterForm extends Component
{
    /**
     * Create a new component instance.
     */
    public function __construct(
        public $langKey = null
    ) {
        //
    }

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        return view('components.backend.forms.footer-form');
    }
}
