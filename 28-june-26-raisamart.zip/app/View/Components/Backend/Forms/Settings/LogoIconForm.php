<?php

namespace App\View\Components\Backend\Forms\Settings;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

class LogoIconForm extends Component
{
    /**
     * Create a new component instance.
     */
    public function __construct()
    {
        //
    }

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        return view('components.backend.forms.settings.logo-icon-form');
    }
}
