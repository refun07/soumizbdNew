<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('return_request_items', function (Blueprint $table) {
            $table->unsignedBigInteger('exchange_product_variation_id')->nullable()->after('product_variation_id');

            $table->foreign('exchange_product_variation_id')
                ->references('id')
                ->on('product_variations')
                ->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::table('return_request_items', function (Blueprint $table) {
            $table->dropForeign(['exchange_product_variation_id']);
            $table->dropColumn(['exchange_product_variation_id']);
        });
    }
};
